#
# Cookbook:: attvh
# Recipe:: default
#
# Copyright:: 2020, The Authors, All Rights Reserved.

package %w(httpd elinks)

node["lamp-stack"]["sites"].each do |sitename, data|
 document_root = "/var/www/html/#{sitename}"
 directory document_root do
    mode "0755"
    recursive true
 end

 template "/etc/httpd/conf.d/#{sitename}.conf" do
    source "virtualhosts.erb"
    mode "0644"
 variables(
 :document_root => document_root,
 :port => data["port"],
 :serveradmin => data["serveradmin"],
 :servername => data["servername"]
    )
 end

 file "/var/www/html/#{sitename}/index.html" do
   content "#{sitename}"
 end

end

service 'httpd' do
 action :restart
end

