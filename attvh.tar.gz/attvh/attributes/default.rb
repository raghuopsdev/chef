default["lamp-stack"]["sites"]["google.com"]={"port"=>80,"servername"=>"google.com","serveradmin"=>"google@example.com"}
default["lamp-stack"]["sites"]["microsoft.com"] = { "port" =>80, "servername" =>"microsoft.com", "serveradmin" =>"microsoft@example.com" }
